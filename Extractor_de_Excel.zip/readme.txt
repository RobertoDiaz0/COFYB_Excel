COFYB Extractor de Excel 1.1

El archivo Colegiados.xlsx es la base de datos con la información de los colegiados.

El archivo Nombre.xlsx es un recorte de 100 extractos bancarios de los pagos de la cuota de colegiación y otros conceptos.

Cuando ejecute el programa ingrese "Nombre.xlsx". Cuando el programa termine de ejecutarse podrá ver en las columnas I, J y K

de "Nombre.xlsx" el número de cuit extraído (siempre que el valor en la columna de Cŕedito sea mayor a 0), el número y el nombre

de Colegiados respectivamente (siempre que haya conincidencia del cuit con alguno en Colegiados.xlsx).

